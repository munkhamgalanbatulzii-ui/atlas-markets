#!/usr/bin/env python3
"""Refresh ATLAS share prices from an authorized data feed.

Input schema: JSON either a list, or {'prices': [...]}, with rows:
 {'ticker':'KHAN','date':'2026-11-06', 'open':..., 'high':..., 'low':..., 'close':..., 'volume':..., 'value':...}
Monetary prices in MNT; value in MNT; volume in shares.

Fails safely on missing feeds/invalid data, leaves index.html intact.
"""
from __future__ import annotations
import datetime as dt
import json
import math
import os
import re
import sys
import urllib.request
from pathlib import Path
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parents[1]
SITE = HERE / 'index.html'
PATTERN = re.compile(r'(<script type="application/json" id="dataset">)(.*?)(</script>)', re.S)


def nval(v, name, positive=False, nonnegative=False):
    try: val = float(v)
    except (ValueError, TypeError): raise ValueError(f'{name}: тоон утга биш')
    if not math.isfinite(val) or (positive and val <= 0) or (nonnegative and val < 0):
        raise ValueError(f'{name}: утга зөвшөөрөгдөхгүй')
    return val


def normalize(row, allowed, today):
    ticker = str(row.get('ticker', row.get('symbol', ''))).upper().strip()
    if ticker not in allowed:
        return None
    date = str(row.get('date', '')).strip()
    try: d = dt.date.fromisoformat(date)
    except ValueError: raise ValueError(f'{ticker}: YYYY-MM-DD огноо шаардлагатай')
    if not dt.date(1990, 1, 1) <= d <= today:
        raise ValueError(f'{ticker}: ирээдүйн эсвэл сэжигтэй огноо {date}')
    o = nval(row.get('open'), 'open', positive=True)
    h = nval(row.get('high'), 'high', positive=True)
    lo = nval(row.get('low'), 'low', positive=True)
    c = nval(row.get('close'), 'close', positive=True)
    v = nval(row.get('volume'), 'volume', nonnegative=True)
    value = nval(row.get('value'), 'value', nonnegative=True)
    if lo > min(o, c) or h < max(o, c) or lo > h:
        raise ValueError(f'{ticker} {date}: OHLC хоорондоо зөрчилтэй')
    if v <= 0:
        # No trade: do not insert a made-up closing price.
        return None
    return ticker, [date, o, h, lo, c, int(v), value]


def main():
    url = os.environ.get('ATLAS_PRICE_FEED_URL', '').strip()
    if not url:
        print('ATLAS_PRICE_FEED_URL тохируулаагүй: ханшийн таталт идэвхгүй (өгөгдөл өөрчлөгдөхгүй).')
        return 0
    if not url.startswith('https://'):
        raise RuntimeError('Зөвхөн HTTPS өгөгдлийн эх сурвалж зөвшөөрнө.')
    html = SITE.read_text(encoding='utf-8')
    match = PATTERN.search(html)
    if not match:
        raise RuntimeError('index.html доторх dataset олдсонгүй.')
    data = json.loads(match.group(2))
    if not isinstance(data.get('companies'), list) or len(data['companies']) != 26:
        raise RuntimeError('26 компанийн бүртгэл алдагдсан байна.')
    companies = {c['symbol']: c for c in data['companies']}
    headers = {'Accept': 'application/json', 'User-Agent': 'ATLAS-Markets-Authorized-Feed/1.0'}
    token = os.environ.get('ATLAS_PRICE_FEED_TOKEN', '').strip()
    if token:
        headers['Authorization'] = f'Bearer {token}'
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=35) as response:
        incoming = json.load(response)
    if isinstance(incoming, dict): incoming = incoming.get('prices')
    if not isinstance(incoming, list) or not incoming:
        raise RuntimeError('Тэжээлд үнэ бүхий массив байхгүй; өмнөх өгөгдлийг хадгаллаа.')
    today = dt.datetime.now(ZoneInfo('Asia/Ulaanbaatar')).date()
    parsed = {}
    for raw in incoming:
        if not isinstance(raw, dict): raise RuntimeError('Ханшийн мөр буруу форматтай.')
        item = normalize(raw, companies, today)
        if item:
            ticker, record = item
            key = (ticker, record[0])
            if key in parsed and parsed[key] != record:
                raise RuntimeError(f'Нэг өдөр өөр өөр ханш ирлээ: {ticker}/{record[0]}')
            parsed[key] = record
    if not parsed:
        print('Тэжээлээс 26 компанийн хүчинтэй арилжааны мөр олдсонгүй.')
        return 0
    changes = 0
    for symbol, company in companies.items():
        history = company['priceHistory']
        store = {v[0]: v for v in history}
        own = [(date, value) for (sym, date), value in parsed.items() if sym == symbol]
        for day, record in own:
            # Never silently revise a historical trading record: correction needs review.
            if day in store and store[day] != record:
                if day < max(store):
                    raise RuntimeError(f'{symbol}/{day} түүхэн өгөгдөл өөрчлөгдсөн — гараар шалгана уу.')
            if store.get(day) != record:
                store[day] = record
                changes += 1
        if not own:
            continue
        items = sorted(store.values(), key=lambda x:x[0])
        company['priceHistory'] = items
        metrics = company['metrics']
        latest = items[-1]
        prev = items[-2] if len(items) >= 2 else None
        last = float(latest[4])
        shares = company.get('shares')
        metrics.update({
            'price': last,
            'priceDate': latest[0],
            'firstTradeDate': items[0][0],
            'price1d': 100 * (last / prev[4] - 1) if prev and prev[4] else None,
            'volume': latest[5],
            'value': latest[6],
            'marketcap': last * shares / 1_000_000 if shares and shares > 0 else None,
            'pe': last / metrics['eps'] if metrics.get('eps') and metrics['eps'] > 0 else None,
            'pb': last / metrics['bvps'] if metrics.get('bvps') and metrics['bvps'] > 0 else None,
            'divYield': 100 * metrics['dividends12mDPS'] / last if metrics.get('dividends12mDPS') is not None else None,
        })
    if not changes:
        print('Ханшийн шинэ мөр байхгүй; вебийг өөрчлөхгүй.')
        return 0
    data['summary']['priceRecords'] = sum(len(c['priceHistory']) for c in data['companies'])
    data['summary']['totalMarketcapMillion'] = sum(c['metrics'].get('marketcap') or 0 for c in data['companies'])
    data['summary']['lastPriceAsOf'] = max(c['metrics'].get('priceDate') or '' for c in data['companies'])
    data['summary']['asof'] = today.isoformat()
    data['summary']['updatedFrom'] = 'Анхны Excel + зөвшөөрөгдсөн ханшийн тэжээл'
    new_json = json.dumps(data, separators=(',', ':'), ensure_ascii=False).replace('</', '<\\/')
    updated = html[:match.start(2)] + new_json + html[match.end(2):]
    temp = SITE.with_suffix('.html.tmp')
    temp.write_text(updated, encoding='utf-8')
    temp.replace(SITE)
    print(f'{changes} ханшийн мөр шинэчлэгдлээ; хамгийн сүүлийн огноо: {data["summary"]["lastPriceAsOf"]}.')
    return 0

if __name__ == '__main__':
    try: sys.exit(main())
    except Exception as e:
        print(f'Алдаа — өгөгдөл хадгалагдсан: {e}', file=sys.stderr)
        sys.exit(1)
